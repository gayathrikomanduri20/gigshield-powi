import React from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Shield, LayoutDashboard, FileText, LogOut, User } from 'lucide-react';
import { useAuth } from '../App';

export default function Layout() {
  const { profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/register');
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Claims', path: '/claims', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-bg-surface flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-brand-blue text-white flex flex-col border-r border-ink-deep">
        <div className="p-8 flex items-center gap-3">
          <Shield className="w-8 h-8 text-white" />
          <h1 className="text-2xl font-bold tracking-tighter italic serif">GigShield</h1>
        </div>

        <nav className="flex-1 px-4 py-8 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-4 px-4 py-3 rounded-md transition-all ${
                  isActive
                    ? 'bg-white text-brand-blue'
                    : 'hover:bg-white hover:bg-opacity-10'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium uppercase text-xs tracking-widest">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-8 border-t border-white border-opacity-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <User className="w-6 h-6 text-brand-blue" />
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold truncate">{profile?.displayName}</p>
              <p className="text-xs opacity-50 truncate">{profile?.email}</p>
            </div>
          </div>
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-4 py-2 text-xs font-bold uppercase tracking-widest hover:text-brand-red transition-all"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-6 md:p-12">
        <div className="max-w-6xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
