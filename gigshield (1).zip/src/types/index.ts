export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  workZone?: string;
  location?: { lat: number; lng: number };
  createdAt: string;
  role: 'user' | 'admin';
}

export interface InsurancePolicy {
  id: string;
  userId: string;
  type: 'Income Protection' | 'Accident Cover' | 'Health';
  premium: number;
  coverage: number;
  status: 'active' | 'expired' | 'cancelled';
  startDate: string;
  endDate: string;
}

export interface InsuranceClaim {
  id: string;
  userId: string;
  policyId: string;
  reason: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  triggeredBy: 'manual' | 'automated';
  timestamp: string;
}

export interface RiskZone {
  id: string;
  name: string;
  riskLevel: number;
  safetyHistory: string;
}
