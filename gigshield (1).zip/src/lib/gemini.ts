import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export interface PremiumCalculationInput {
  workZone: string;
  weatherForecast: string;
  historicalRiskLevel: number; // 0 to 1
  basePremium: number;
}

export interface PremiumCalculationResult {
  weeklyPremium: number;
  reasoning: string;
  riskFactors: string[];
}

export async function calculateDynamicPremium(input: PremiumCalculationInput): Promise<PremiumCalculationResult> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Calculate a dynamic weekly insurance premium for a gig worker based on the following factors:
    - Work Zone: ${input.workZone}
    - Weather Forecast: ${input.weatherForecast}
    - Historical Risk Level (0-1): ${input.historicalRiskLevel}
    - Base Premium: ₹${input.basePremium}
    
    The premium should adjust based on hyper-local risk factors. For example, ₹2 less per week if the zone is safe from water logging, or more if severe weather is predicted.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          weeklyPremium: { type: Type.NUMBER },
          reasoning: { type: Type.STRING },
          riskFactors: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["weeklyPremium", "reasoning", "riskFactors"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function checkAutomatedClaimTriggers(userLocation: string, weatherData: any): Promise<{ shouldTrigger: boolean; reason: string; amount: number } | null> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following data to determine if an automated "Loss of Income" claim should be triggered for a gig worker:
    - User Location: ${userLocation}
    - Weather/Event Data: ${JSON.stringify(weatherData)}
    
    Triggers include: severe flooding, road closures, or extreme heat preventing work.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          shouldTrigger: { type: Type.BOOLEAN },
          reason: { type: Type.STRING },
          amount: { type: Type.NUMBER }
        },
        required: ["shouldTrigger", "reason", "amount"]
      }
    }
  });

  const result = JSON.parse(response.text);
  return result.shouldTrigger ? result : null;
}
