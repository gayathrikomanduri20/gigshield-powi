import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Shield, Calendar, CreditCard, ArrowLeft, AlertCircle, CheckCircle2 } from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, FirestoreOperation } from '../lib/firebase';
import { InsurancePolicy } from '../types';
import { format } from 'date-fns';

export default function PolicyDetails() {
  const { id } = useParams<{ id: string }>();
  const [policy, setPolicy] = useState<InsurancePolicy | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;

    const unsub = onSnapshot(doc(db, 'policies', id), (snapshot) => {
      if (snapshot.exists()) {
        setPolicy({ id: snapshot.id, ...snapshot.data() } as InsurancePolicy);
      }
      setLoading(false);
    }, (err) => handleFirestoreError(err, FirestoreOperation.GET, `policies/${id}`));

    return () => unsub();
  }, [id]);

  if (loading) return <div className="animate-pulse bg-white border border-[#141414] h-64 rounded-lg" />;
  if (!policy) return <div className="text-center p-12">Policy not found.</div>;

  return (
    <div className="space-y-8">
      <Link to="/" className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-50 hover:opacity-100 transition-all">
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </Link>

      <div className="bg-white border-2 border-ink-deep p-12 rounded-lg shadow-[12px_12px_0px_0px_#2563eb] space-y-12">
        <div className="flex justify-between items-start">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-brand-red" />
              <h1 className="text-4xl font-bold tracking-tighter uppercase text-ink-deep">{policy.type}</h1>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                policy.status === 'active' ? 'bg-green-100 text-brand-green' : 'bg-red-100 text-brand-red'
              }`}>
                {policy.status}
              </span>
              <span className="text-xs font-mono opacity-50 text-ink-deep"># {policy.id}</span>
            </div>
          </div>
          <div className="text-right space-y-2">
            <p className="text-[10px] font-bold uppercase tracking-widest opacity-50 text-ink-deep">Weekly Premium</p>
            <p className="text-4xl font-bold tracking-tighter text-brand-blue">₹{policy.premium}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 border-t border-b border-ink-deep border-opacity-10 py-12">
          <div className="space-y-4">
            <div className="flex items-center gap-3 opacity-50 text-ink-deep">
              <Calendar className="w-5 h-5" />
              <p className="text-xs font-bold uppercase tracking-widest">Coverage Period</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm font-bold text-ink-deep">{format(new Date(policy.startDate), 'MMM dd, yyyy')}</p>
              <p className="text-xs opacity-50 text-ink-deep">to</p>
              <p className="text-sm font-bold text-ink-deep">{format(new Date(policy.endDate), 'MMM dd, yyyy')}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3 opacity-50 text-ink-deep">
              <CreditCard className="w-5 h-5" />
              <p className="text-xs font-bold uppercase tracking-widest">Coverage Limit</p>
            </div>
            <p className="text-3xl font-bold tracking-tighter text-brand-blue">₹{policy.coverage}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3 opacity-50 text-ink-deep">
              <AlertCircle className="w-5 h-5" />
              <p className="text-xs font-bold uppercase tracking-widest">Policy Terms</p>
            </div>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-xs font-bold text-ink-deep">
                <CheckCircle2 className="w-3 h-3 text-brand-green" />
                Income Protection
              </li>
              <li className="flex items-center gap-2 text-xs font-bold text-ink-deep">
                <CheckCircle2 className="w-3 h-3 text-brand-green" />
                Zero-Touch Claims
              </li>
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-bold italic serif">Coverage Details</h3>
          <p className="text-sm text-[#141414] opacity-70 leading-relaxed max-w-2xl">
            This policy provides comprehensive income protection for gig workers. It covers loss of income due to 
            hyper-local disruptions such as severe weather, road closures, and extreme environmental conditions. 
            Claims are automatically processed using GigShield's proprietary risk monitoring engine.
          </p>
        </div>
      </div>
    </div>
  );
}
