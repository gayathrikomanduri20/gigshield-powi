import React from 'react';
import { Shield, ArrowRight } from 'lucide-react';
import { useAuth } from '../App';

export default function Register() {
  const { signIn } = useAuth();

  return (
    <div className="min-h-screen bg-bg-surface flex flex-col items-center justify-center p-6">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        {/* Left Side: Brand & Hero */}
        <div className="space-y-8">
          <div className="flex items-center gap-3">
            <Shield className="w-12 h-12 text-brand-red" />
            <h1 className="text-4xl font-bold tracking-tighter italic serif text-ink-deep">GigShield</h1>
          </div>
          
          <h2 className="text-6xl font-bold leading-none tracking-tight text-ink-deep">
            INSURANCE <br />
            FOR THE <br />
            <span className="italic serif text-brand-blue">GIG ECONOMY</span>
          </h2>
          
          <p className="text-lg text-ink-deep opacity-70 max-w-md">
            Dynamic premiums based on hyper-local risk. Zero-touch claims triggered by real-world disruptions.
          </p>

          <div className="flex flex-wrap gap-4 pt-4">
            <div className="px-4 py-2 border border-brand-red rounded-full text-xs font-bold uppercase tracking-widest text-brand-red">
              Dynamic Pricing
            </div>
            <div className="px-4 py-2 border border-brand-green rounded-full text-xs font-bold uppercase tracking-widest text-brand-green">
              Automated Claims
            </div>
            <div className="px-4 py-2 border border-brand-blue rounded-full text-xs font-bold uppercase tracking-widest text-brand-blue">
              Income Protection
            </div>
          </div>
        </div>

        {/* Right Side: Login Card */}
        <div className="bg-white border-2 border-ink-deep p-12 rounded-lg shadow-[12px_12px_0px_0px_#2563eb] space-y-8">
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-ink-deep">Get Started</h3>
            <p className="text-sm text-ink-deep opacity-60">Join 50,000+ gig workers protecting their income.</p>
          </div>

          <button
            onClick={signIn}
            className="w-full group flex items-center justify-between px-8 py-4 bg-brand-red text-white font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all"
          >
            <span>Sign in with Google</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
          </button>

          <div className="pt-8 border-t border-[#141414] border-opacity-10">
            <p className="text-[10px] text-[#141414] opacity-50 uppercase tracking-widest leading-relaxed">
              By signing in, you agree to our Terms of Service and Privacy Policy. 
              GigShield is a registered insurance intermediary.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
