import React, { useEffect, useState } from 'react';
import { Shield, TrendingUp, AlertCircle, CheckCircle2, ArrowRight, CloudRain, Sun, MapPin } from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, FirestoreOperation } from '../lib/firebase';
import { useAuth } from '../App';
import { InsurancePolicy, InsuranceClaim } from '../types';
import { calculateDynamicPremium, PremiumCalculationResult } from '../lib/gemini';
import { format } from 'date-fns';

export default function Dashboard() {
  const { profile } = useAuth();
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [claims, setClaims] = useState<InsuranceClaim[]>([]);
  const [calculating, setCalculating] = useState(false);
  const [calcResult, setCalcResult] = useState<PremiumCalculationResult | null>(null);

  useEffect(() => {
    if (!profile) return;

    const policiesQuery = query(collection(db, 'policies'), where('userId', '==', profile.uid));
    const claimsQuery = query(collection(db, 'claims'), where('userId', '==', profile.uid));

    const unsubPolicies = onSnapshot(policiesQuery, (snapshot) => {
      setPolicies(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InsurancePolicy)));
    }, (err) => handleFirestoreError(err, FirestoreOperation.LIST, 'policies'));

    const unsubClaims = onSnapshot(claimsQuery, (snapshot) => {
      setClaims(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InsuranceClaim)));
    }, (err) => handleFirestoreError(err, FirestoreOperation.LIST, 'claims'));

    return () => {
      unsubPolicies();
      unsubClaims();
    };
  }, [profile]);

  const handleCalculatePremium = async () => {
    if (!profile) return;
    setCalculating(true);
    try {
      const result = await calculateDynamicPremium({
        workZone: profile.workZone || 'Mumbai Central',
        weatherForecast: 'Light rain expected, humidity 80%',
        historicalRiskLevel: 0.2,
        basePremium: 100
      });
      setCalcResult(result);
    } catch (error) {
      console.error('Calculation error:', error);
    } finally {
      setCalculating(false);
    }
  };

  const handleBuyPolicy = async () => {
    if (!profile || !calcResult) return;
    try {
      const newPolicy: Omit<InsurancePolicy, 'id'> = {
        userId: profile.uid,
        type: 'Income Protection',
        premium: calcResult.weeklyPremium,
        coverage: 5000,
        status: 'active',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      };
      await addDoc(collection(db, 'policies'), newPolicy);
      setCalcResult(null);
    } catch (error) {
      handleFirestoreError(error, FirestoreOperation.CREATE, 'policies');
    }
  };

  return (
    <div className="space-y-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-ink-deep">DASHBOARD</h1>
          <p className="text-ink-deep opacity-50 uppercase text-xs font-bold tracking-widest mt-2">
            Welcome back, {profile?.displayName}
          </p>
        </div>
        <div className="flex items-center gap-4 bg-white border border-ink-deep px-6 py-3 rounded-md">
          <MapPin className="w-4 h-4 text-brand-blue" />
          <span className="text-sm font-bold uppercase tracking-widest text-ink-deep">{profile?.workZone || 'Set Work Zone'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Policies */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold italic serif text-ink-deep">Active Policies</h3>
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-50 text-ink-deep">{policies.length} Total</span>
          </div>

          {policies.length > 0 ? (
            <div className="space-y-4">
              {policies.map((policy) => (
                <div key={policy.id} className="bg-white border border-ink-deep p-6 rounded-lg group hover:bg-brand-blue hover:text-white transition-all cursor-pointer">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <h4 className="text-lg font-bold uppercase tracking-tight">{policy.type}</h4>
                      <p className="text-xs opacity-50 font-mono">ID: {policy.id.slice(0, 8)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold tracking-tighter">₹{policy.premium}/wk</p>
                      <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Premium</p>
                    </div>
                  </div>
                  <div className="mt-8 grid grid-cols-2 gap-4 border-t border-ink-deep border-opacity-10 pt-4 group-hover:border-white group-hover:border-opacity-20">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Coverage</p>
                      <p className="text-sm font-bold">₹{policy.coverage}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Expires</p>
                      <p className="text-sm font-bold">{format(new Date(policy.endDate), 'MMM dd, yyyy')}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white border-2 border-dashed border-ink-deep border-opacity-20 p-12 rounded-lg text-center space-y-4">
              <Shield className="w-12 h-12 text-brand-red opacity-20 mx-auto" />
              <p className="text-ink-deep opacity-50 font-bold uppercase text-xs tracking-widest">No active policies found</p>
              <button 
                onClick={handleCalculatePremium}
                className="px-6 py-2 bg-brand-red text-white text-xs font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all"
              >
                Get Protected
              </button>
            </div>
          )}
        </div>

        {/* Dynamic Premium Calculator */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold italic serif text-ink-deep">Dynamic Pricing</h3>
          
          <div className="bg-white border border-ink-deep p-8 rounded-lg shadow-[8px_8px_0px_0px_#e11d48] space-y-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-bg-surface rounded-full">
                <CloudRain className="w-6 h-6 text-brand-blue" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Current Risk</p>
                <p className="text-sm font-bold text-ink-deep">Low (0.2)</p>
              </div>
            </div>

            {!calcResult ? (
              <div className="space-y-4">
                <p className="text-sm text-ink-deep opacity-70">
                  Our AI model calculates your premium based on real-time weather, traffic, and zone safety.
                </p>
                <button
                  onClick={handleCalculatePremium}
                  disabled={calculating}
                  className="w-full py-4 bg-brand-blue text-white font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all disabled:opacity-50"
                >
                  {calculating ? 'Calculating...' : 'Calculate Premium'}
                </button>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center p-6 bg-bg-surface rounded-lg">
                  <p className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-1">Weekly Premium</p>
                  <p className="text-4xl font-bold tracking-tighter text-brand-green">₹{calcResult.weeklyPremium}</p>
                </div>

                <div className="space-y-3">
                  <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Risk Factors</p>
                  <ul className="space-y-2">
                    {calcResult.riskFactors.map((factor, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs font-bold text-ink-deep">
                        <CheckCircle2 className="w-3 h-3 text-brand-green" />
                        {factor}
                      </li>
                    ))}
                  </ul>
                </div>

                <p className="text-xs text-ink-deep opacity-70 italic serif leading-relaxed">
                  "{calcResult.reasoning}"
                </p>

                <button
                  onClick={handleBuyPolicy}
                  className="w-full py-4 bg-brand-green text-white font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all"
                >
                  Buy Policy Now
                </button>
                <button
                  onClick={() => setCalcResult(null)}
                  className="w-full py-2 text-[10px] font-bold uppercase tracking-widest opacity-50 hover:opacity-100 transition-all"
                >
                  Recalculate
                </button>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white border border-ink-deep p-4 rounded-lg">
              <TrendingUp className="w-4 h-4 text-brand-green mb-2" />
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Total Claims</p>
              <p className="text-xl font-bold text-ink-deep">₹{claims.reduce((acc, curr) => acc + (curr.status === 'approved' ? curr.amount : 0), 0)}</p>
            </div>
            <div className="bg-white border border-ink-deep p-4 rounded-lg">
              <AlertCircle className="w-4 h-4 text-brand-red mb-2" />
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">Active Claims</p>
              <p className="text-xl font-bold text-ink-deep">{claims.filter(c => c.status === 'pending').length}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
