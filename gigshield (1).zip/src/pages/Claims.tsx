import React, { useEffect, useState } from 'react';
import { FileText, AlertCircle, CheckCircle2, XCircle, Plus, Zap, ArrowRight, ShieldCheck } from 'lucide-react';
import { collection, query, where, onSnapshot, addDoc, doc, updateDoc, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, FirestoreOperation } from '../lib/firebase';
import { useAuth } from '../App';
import { InsuranceClaim, InsurancePolicy } from '../types';
import { checkAutomatedClaimTriggers } from '../lib/gemini';
import { format } from 'date-fns';

export default function Claims() {
  const { profile } = useAuth();
  const [claims, setClaims] = useState<InsuranceClaim[]>([]);
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [simulating, setSimulating] = useState(false);
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualClaim, setManualClaim] = useState({ policyId: '', reason: '', amount: 0 });

  useEffect(() => {
    if (!profile) return;

    const claimsQuery = query(collection(db, 'claims'), where('userId', '==', profile.uid));
    const policiesQuery = query(collection(db, 'policies'), where('userId', '==', profile.uid));

    const unsubClaims = onSnapshot(claimsQuery, (snapshot) => {
      setClaims(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InsuranceClaim)));
    }, (err) => handleFirestoreError(err, FirestoreOperation.LIST, 'claims'));

    const unsubPolicies = onSnapshot(policiesQuery, (snapshot) => {
      setPolicies(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InsurancePolicy)));
    }, (err) => handleFirestoreError(err, FirestoreOperation.LIST, 'policies'));

    return () => {
      unsubClaims();
      unsubPolicies();
    };
  }, [profile]);

  const handleSimulateTrigger = async () => {
    if (!profile || policies.length === 0) return;
    setSimulating(true);
    try {
      // Mock weather data for simulation
      const mockWeather = { condition: 'Severe Flooding', rainfall: '150mm', roadClosure: true };
      const trigger = await checkAutomatedClaimTriggers(profile.workZone || 'Mumbai Central', mockWeather);

      if (trigger) {
        const newClaim: Omit<InsuranceClaim, 'id'> = {
          userId: profile.uid,
          policyId: policies[0].id,
          reason: trigger.reason,
          amount: trigger.amount,
          status: 'approved', // Automated claims are pre-approved in this demo
          triggeredBy: 'automated',
          timestamp: new Date().toISOString(),
        };
        await addDoc(collection(db, 'claims'), newClaim);
        alert(`Automated Claim Triggered: ${trigger.reason}. Amount ₹${trigger.amount} approved.`);
      } else {
        alert('No claim triggers detected for current conditions.');
      }
    } catch (error) {
      console.error('Simulation error:', error);
    } finally {
      setSimulating(false);
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !manualClaim.policyId) return;
    try {
      const newClaim: Omit<InsuranceClaim, 'id'> = {
        userId: profile.uid,
        policyId: manualClaim.policyId,
        reason: manualClaim.reason,
        amount: Number(manualClaim.amount),
        status: 'pending',
        triggeredBy: 'manual',
        timestamp: new Date().toISOString(),
      };
      await addDoc(collection(db, 'claims'), newClaim);
      setShowManualForm(false);
      setManualClaim({ policyId: '', reason: '', amount: 0 });
    } catch (error) {
      handleFirestoreError(error, FirestoreOperation.CREATE, 'claims');
    }
  };

  return (
    <div className="space-y-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-ink-deep">CLAIMS</h1>
          <p className="text-ink-deep opacity-50 uppercase text-xs font-bold tracking-widest mt-2">
            Zero-touch claims management
          </p>
        </div>
        <div className="flex gap-4">
          <button
            onClick={handleSimulateTrigger}
            disabled={simulating || policies.length === 0}
            className="flex items-center gap-3 px-6 py-3 bg-brand-blue text-white text-xs font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all disabled:opacity-50"
          >
            <Zap className="w-4 h-4" />
            {simulating ? 'Simulating...' : 'Simulate Trigger'}
          </button>
          <button
            onClick={() => setShowManualForm(!showManualForm)}
            className="flex items-center gap-3 px-6 py-3 border-2 border-ink-deep text-ink-deep text-xs font-bold uppercase tracking-widest hover:bg-brand-red hover:text-white hover:border-brand-red transition-all"
          >
            <Plus className="w-4 h-4" />
            Manual Claim
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Claims List */}
        <div className="lg:col-span-2 space-y-8">
          {showManualForm && (
            <form onSubmit={handleManualSubmit} className="bg-white border-2 border-ink-deep p-8 rounded-lg space-y-6 animate-in slide-in-from-top-4 duration-300">
              <h3 className="text-xl font-bold italic serif text-ink-deep">Submit Manual Claim</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest opacity-50">Select Policy</label>
                  <select
                    required
                    value={manualClaim.policyId}
                    onChange={(e) => setManualClaim({ ...manualClaim, policyId: e.target.value })}
                    className="w-full p-3 border border-ink-deep rounded-md text-sm"
                  >
                    <option value="">Select a policy</option>
                    {policies.map(p => (
                      <option key={p.id} value={p.id}>{p.type} (₹{p.coverage})</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest opacity-50">Claim Amount (₹)</label>
                  <input
                    required
                    type="number"
                    value={manualClaim.amount}
                    onChange={(e) => setManualClaim({ ...manualClaim, amount: Number(e.target.value) })}
                    className="w-full p-3 border border-ink-deep rounded-md text-sm"
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest opacity-50">Reason for Claim</label>
                  <textarea
                    required
                    value={manualClaim.reason}
                    onChange={(e) => setManualClaim({ ...manualClaim, reason: e.target.value })}
                    className="w-full p-3 border border-ink-deep rounded-md text-sm h-24"
                    placeholder="Describe the disruption or incident..."
                  />
                </div>
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowManualForm(false)}
                  className="px-6 py-2 text-xs font-bold uppercase tracking-widest opacity-50 hover:opacity-100 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-8 py-3 bg-brand-blue text-white text-xs font-bold uppercase tracking-widest hover:bg-opacity-90 transition-all"
                >
                  Submit Claim
                </button>
              </div>
            </form>
          )}

          <div className="space-y-4">
            {claims.length > 0 ? (
              <div className="bg-white border border-ink-deep rounded-lg overflow-hidden">
                <div className="grid grid-cols-4 p-4 border-b border-ink-deep bg-bg-surface text-[10px] font-bold uppercase tracking-widest opacity-50">
                  <span>Date</span>
                  <span>Reason</span>
                  <span>Amount</span>
                  <span>Status</span>
                </div>
                {claims.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((claim) => (
                  <div key={claim.id} className="grid grid-cols-4 p-6 border-b border-ink-deep border-opacity-10 items-center hover:bg-bg-surface hover:bg-opacity-20 transition-all">
                    <div className="space-y-1">
                      <p className="text-sm font-bold">{format(new Date(claim.timestamp), 'MMM dd')}</p>
                      <p className="text-[10px] opacity-50 uppercase tracking-widest">{claim.triggeredBy}</p>
                    </div>
                    <p className="text-sm font-medium truncate pr-4">{claim.reason}</p>
                    <p className="text-sm font-bold">₹{claim.amount}</p>
                    <div className="flex items-center gap-2">
                      {claim.status === 'approved' && <CheckCircle2 className="w-4 h-4 text-brand-green" />}
                      {claim.status === 'pending' && <AlertCircle className="w-4 h-4 text-yellow-600" />}
                      {claim.status === 'rejected' && <XCircle className="w-4 h-4 text-brand-red" />}
                      <span className={`text-[10px] font-bold uppercase tracking-widest ${
                        claim.status === 'approved' ? 'text-brand-green' : 
                        claim.status === 'pending' ? 'text-yellow-600' : 'text-brand-red'
                      }`}>
                        {claim.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white border-2 border-dashed border-ink-deep border-opacity-20 p-12 rounded-lg text-center space-y-4">
                <FileText className="w-12 h-12 text-brand-blue opacity-20 mx-auto" />
                <p className="text-ink-deep opacity-50 font-bold uppercase text-xs tracking-widest">No claims history found</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: How it works */}
        <div className="space-y-8">
          <div className="bg-brand-blue text-white p-8 rounded-lg space-y-6">
            <ShieldCheck className="w-10 h-10" />
            <h3 className="text-2xl font-bold italic serif">Zero-Touch Claims</h3>
            <p className="text-sm opacity-70 leading-relaxed">
              GigShield monitors hyper-local data. If a disruption occurs in your work zone, we trigger the claim automatically.
            </p>
            
            <div className="space-y-4 pt-4">
              <div className="flex gap-4">
                <div className="w-6 h-6 rounded-full bg-white text-brand-blue flex items-center justify-center text-[10px] font-bold">1</div>
                <p className="text-xs font-bold uppercase tracking-widest">Disruption Detected</p>
              </div>
              <div className="flex gap-4">
                <div className="w-6 h-6 rounded-full bg-white text-brand-blue flex items-center justify-center text-[10px] font-bold">2</div>
                <p className="text-xs font-bold uppercase tracking-widest">Policy Verified</p>
              </div>
              <div className="flex gap-4">
                <div className="w-6 h-6 rounded-full bg-white text-brand-blue flex items-center justify-center text-[10px] font-bold">3</div>
                <p className="text-xs font-bold uppercase tracking-widest">Instant Approval</p>
              </div>
            </div>
          </div>

          <div className="bg-white border border-ink-deep p-8 rounded-lg space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-widest text-ink-deep">Recent Triggers</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-50">Water Logging - Zone A</span>
                <span className="font-bold text-brand-red">ACTIVE</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-50">Road Closure - Zone C</span>
                <span className="font-bold text-brand-green">RESOLVED</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="opacity-50">Extreme Heat - Zone B</span>
                <span className="font-bold text-yellow-600">MONITORING</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
